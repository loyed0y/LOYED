/* ============================================================
   LOYED — main controller, navigation & UI
   ============================================================ */
var LOYEDUI = (function(){
  var S = LOYEDStore;

  /* ---------- boot ---------- */
  function boot(){
    S.init();
    var st = S.get();
    // apply theme + lang
    S.setTheme(st.me.theme || "cyberpunk");
    S.setLang(st.me.lang || "ar");
    // splash timer
    setTimeout(function(){
      hide("#splash");
      if(st.me.registered){
        show("#app");
        renderApp();
      } else {
        show("#register");
      }
    }, 1600);
    bindGlobal();
  }

  function hide(sel){ var el=document.querySelector(sel); if(el) el.classList.add("hidden"); }
  function show(sel){ var el=document.querySelector(sel); if(el) el.classList.remove("hidden"); }

  /* ---------- registration ---------- */
  function register(){
    var st = S.get();
    var cc = document.getElementById("cc").value;
    var phone = document.getElementById("phoneInput").value.trim();
    if(!phone){ toast("أدخل رقم الهاتف"); return; }
    st.me.phone = cc+" "+phone;
    st.me.registered = true;
    st.me.name = "مستخدم LOYED";
    st.me.loyedId = "@loyed_"+phone.slice(-4);
    S.save();
    hide("#register"); show("#app"); renderApp();
    toast("أهلاً بك في LOYED 💜");
  }
  function demoLogin(){
    var st = S.get();
    st.me.registered = true; S.save();
    hide("#register"); show("#app"); renderApp();
    toast("دخول تجريبي ✨");
  }

  /* ---------- global bindings ---------- */
  function bindGlobal(){
    document.getElementById("regBtn").addEventListener("click", register);
    document.getElementById("useDemoBtn").addEventListener("click", demoLogin);

    // rail nav
    document.querySelectorAll(".rail-btn[data-nav]").forEach(function(btn){
      btn.addEventListener("click", function(){ navTo(btn.dataset.nav); });
    });
    document.getElementById("railSettings").addEventListener("click", function(){ navTo("settings"); });
    document.getElementById("railMe").addEventListener("click", function(){ navTo("profile"); });

    document.getElementById("railMe").querySelector("#meAvatarMini").textContent =
      S.initials(S.get().me.name);

    // owner gate buttons
    var ov=document.getElementById("ownerVerifyBtn");
    if(ov) ov.addEventListener("click", function(){ SCREENS.verifyOwner(); });
    var oc=document.getElementById("ownerCancelBtn");
    if(oc) oc.addEventListener("click", function(){ SCREENS.cancelOwner(); });
    var ocode=document.getElementById("ownerCodeInput");
    if(ocode) ocode.addEventListener("keydown", function(e){ if(e.key==="Enter") document.getElementById("owner2faInput").focus(); });
    var ofa=document.getElementById("owner2faInput");
    if(ofa) ofa.addEventListener("keydown", function(e){ if(e.key==="Enter") SCREENS.verifyOwner(); });
  }

  /* ---------- app render ---------- */
  function renderApp(){
    navTo(S.t().currentScreen || "chats");
  }

  function navTo(screen){
    S.t().currentScreen = screen;
    // reset owner panel if open
    var op = document.getElementById("ownerPanel");
    if(!op.classList.contains("hidden") && screen!=="owner"){ op.classList.add("hidden"); }
    if(!document.getElementById("ownerGate").classList.contains("hidden")) return;

    // rail active
    document.querySelectorAll(".rail-btn[data-nav]").forEach(function(b){
      b.classList.toggle("active", b.dataset.nav===screen);
    });
    document.getElementById("railSettings").classList.toggle("active", screen==="settings"||screen==="profile");

    var main = document.getElementById("mainArea");
    main.innerHTML = "";
    var fn = SCREENS[screen] || SCREENS.chats;
    fn(main);

    // hide chat view overlay if switching away
    if(screen!=="chats"){ document.getElementById("chatView").classList.add("hidden"); }
  }

  /* ---------- top bar builder ---------- */
  function topbar(title, opts){
    opts = opts || {};
    var h = '<div class="topbar">';
    h += '<h1>'+title+'</h1>';
    h += '<div class="tb-grow"></div>';
    if(opts.search!==false){
      h += '<input class="search-box" placeholder="'+(opts.searchPh||'بحث...')+'" oninput="LOYEDUI.filterList(this.value)" />';
    }
    if(opts.menu){
      h += '<button class="icon-btn" id="topMenuBtn">⋮</button>';
      h += '<div class="dropdown" id="topDropdown">'+buildMenu(opts.menu)+'</div>';
    }
    if(opts.extra) h += opts.extra;
    h += '</div>';
    return h;
  }

  function buildMenu(items){
    var h = "";
    items.forEach(function(it){
      if(it.divider){ h += '<div class="dropdown-divider"></div>'; return; }
      if(it.loyed){
        h += '<button class="dropdown-item" onclick="'+it.onclick+'"><span class="loyed-mark">L</span>'+it.label+'</button>';
      } else {
        h += '<button class="dropdown-item'+(it.danger?' danger':'')+'" onclick="'+it.onclick+'"><span class="di-ico">'+(it.ico||'')+'</span>'+it.label+'</button>';
      }
    });
    return h;
  }

  /* ---------- dropdown toggle ---------- */
  document.addEventListener("click", function(e){
    var btn = e.target.closest("#topMenuBtn");
    var dd = document.getElementById("topDropdown");
    if(btn){ if(dd){ dd.classList.toggle("open"); e.stopPropagation(); } return; }
    if(dd && !e.target.closest("#topDropdown")) dd.classList.remove("open");
  });

  /* ---------- toast ---------- */
  var toastTimer=null;
  function toast(msg){
    var t = document.getElementById("toast");
    t.textContent = msg; t.classList.add("show");
    clearTimeout(toastTimer);
    toastTimer = setTimeout(function(){ t.classList.remove("show"); }, 2600);
  }

  /* ---------- modal ---------- */
  function modal(opts){
    var root = document.getElementById("modalRoot");
    var h = '<div class="modal">';
    if(opts.title){
      h += '<div class="modal-head"><h3>'+opts.title+'</h3><button class="icon-btn" onclick="LOYEDUI.closeModal()">✕</button></div>';
    }
    h += '<div class="modal-body">'+(opts.body||"")+'</div>';
    if(opts.foot){ h += '<div class="modal-foot">'+opts.foot+'</div>'; }
    h += '</div>';
    root.innerHTML = h; root.classList.remove("hidden");
    if(opts.onMount) opts.onMount(root.querySelector(".modal"));
  }
  function closeModal(){ document.getElementById("modalRoot").classList.add("hidden"); }

  /* ---------- helpers ---------- */
  function avatarHTML(contact, cls){
    cls = cls||"";
    var c = S.findContact(contact.id||contact);
    var bg = S.avatarColor(c.color||0);
    var dot = c.online ? '<span class="dot online" style="position:absolute;bottom:0;inset-inline-end:0;border:2px solid var(--panel)"></span>' : '';
    return '<div class="avatar '+cls+'" style="background:'+bg+'">'+S.initials(c.name)+dot+'</div>';
  }
  function tickHTML(status){
    if(status==="sent") return '<span class="b-tick">✓</span>';
    if(status==="delivered") return '<span class="b-tick">✓✓</span>';
    if(status==="read") return '<span class="b-tick read">✓✓</span>';
    return '';
  }

  function filterList(q){
    document.querySelectorAll(".list-item").forEach(function(li){
      var name = li.getAttribute("data-name")||"";
      li.style.display = !q || name.toLowerCase().indexOf(q.toLowerCase())>=0 ? "" : "none";
    });
  }

  /* ============================================================
     SCREENS
     ============================================================ */
  var SCREENS = {};

  /* ---------- CHATS LIST ---------- */
  SCREENS.chats = function(root){
    var st = S.get();
    var menu = [
      {label:"مجموعة جديدة", ico:"👥", onclick:"LOYEDUI.newGroup()"},
      {label:"قناة جديدة", ico:"📢", onclick:"LOYEDUI.newChannel()"},
      {label:"بث", ico:"📡", onclick:"LOYEDUI.toast('قريباً')"},
      {label:"المفضلة", ico:"⭐", onclick:"LOYEDUI.toast('قريباً')"},
      {label:"المؤرشفة", ico:"📦", onclick:"LOYEDUI.toast('قريباً')"},
      {divider:true},
      {loyed:true, label:"LOYED", onclick:"LOYEDUI.openOwnerGate()"},
      {label:"الإعدادات", ico:"⚙️", onclick:"LOYEDUI.navTo('settings')"},
    ];
    var h = topbar("LOYED "+S.i18n("chats"), {menu:menu});
    h += '<div class="tabs">';
    h += '<button class="tab active" onclick="LOYEDUI.chatTab(\'all\',this)">الكل</button>';
    h += '<button class="tab" onclick="LOYEDUI.chatTab(\'unread\',this)">غير المقروء</button>';
    h += '<button class="tab" onclick="LOYEDUI.chatTab(\'groups\',this)">المجموعات</button>';
    h += '<button class="tab" onclick="LOYEDUI.chatTab(\'channels\',this)">القنوات</button>';
    h += '</div>';
    h += '<div class="content" id="chatListWrap"><div class="list" id="chatList">';
    st.chats.forEach(function(c){ h += chatListItemHTML(c); });
    h += '</div>';
    if(st.chats.length===0) h += '<div class="empty"><div class="em-ico">💬</div>لا توجد محادثات بعد</div>';
    h += '<button class="fab" onclick="LOYEDUI.newChatFab()">✎</button>';
    h += '</div>';
    root.innerHTML = h;
    // update badge
    var total = st.chats.reduce(function(s,c){return s+(c.unread||0);},0);
    var badge = document.getElementById("railChatsBadge");
    if(total>0){ badge.textContent = total; badge.classList.add("show"); } else { badge.classList.remove("show"); }
  };

  function chatListItemHTML(c){
    var st=S.get();
    var name="", avatarCls="", peer;
    if(c.kind==="direct"){ peer=S.findContact(c.peer); name=peer.name; }
    else if(c.kind==="group"){ name=c.name||"مجموعة"; avatarCls="group"; }
    else if(c.kind==="channel"){ name=c.name||"قناة"; avatarCls="channel"; }
    var lastMsg = c.messages && c.messages.length ? c.messages[c.messages.length-1] : null;
    var lastText = lastMsg ? (lastMsg.from==="me"?"أنت: ":"")+lastMsg.text : (c.draft?"مسودة: "+c.draft:"");
    var tick = lastMsg && lastMsg.from==="me" ? '<span class="tick '+((lastMsg.status==="read")?"read":"")+'">'+(lastMsg.status==="sent"?"✓":"✓✓")+'</span> ' : '';
    var pin = c.pinned ? '<span class="pin-ico">📌</span>' : '';
    var mute = c.muted ? '<span class="muted-ico">🔕</span>' : '';
    var avHTML = c.kind==="direct" ? avatarHTML(peer) :
      '<div class="avatar '+avatarCls+'">'+(c.kind==="group"?"👥":(c.kind==="channel"?"📢":"💬"))+'</div>';
    var verified = c.verified ? ' <span style="color:var(--accent)">✔</span>' : '';
    return '<div class="list-item" data-name="'+name+'" data-id="'+c.id+'" onclick="LOYEDUI.openChat(\''+c.id+'\')">'
      + avHTML
      + '<div class="li-body"><div class="li-top"><span class="li-name">'+name+verified+'</span>'
      + '<span class="li-time">'+(lastMsg?S.fmtTime(lastMsg.t):"")+'</span></div>'
      + '<div class="li-top"><span class="li-msg">'+escapeHTML(lastText)+'</span>'
      + '<span class="li-meta">'+pin+mute+tick+(c.unread?'<span class="li-badge">'+c.unread+'</span>':'')+'</span></div></div></div>';
  }

  SCREENS.chatTab = function(tab, btn){
    document.querySelectorAll(".tabs .tab").forEach(function(t){t.classList.remove("active");});
    btn.classList.add("active");
    var st=S.get();
    var wrap=document.getElementById("chatList");
    var list = st.chats.filter(function(c){
      if(tab==="unread") return c.unread>0;
      if(tab==="groups") return c.kind==="group";
      if(tab==="channels") return c.kind==="channel";
      return true;
    });
    wrap.innerHTML = list.map(chatListItemHTML).join("") || '<div class="empty"><div class="em-ico">💬</div>لا توجد محادثات</div>';
  };

  SCREENS.newChatFab = function(){
    var st=S.get();
    var body = '<div class="list">';
    st.contacts.forEach(function(c){
      body += '<div class="list-item" onclick="LOYEDUI.startDirect(\''+c.id+'\')">'+avatarHTML(c)+'<div class="li-body"><div class="li-name">'+c.name+'</div><div class="li-msg">'+(c.loyedId||"")+'</div></div></div>';
    });
    body += '</div>';
    modal({title:"محادثة جديدة", body:body, foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button>'});
  };

  SCREENS.startDirect = function(peerId){
    var st=S.get();
    var existing = st.chats.find(function(c){return c.kind==="direct" && c.peer===peerId;});
    if(!existing) existing = S.createChat(peerId,"direct");
    closeModal();
    openChat(existing.id);
  };

  SCREENS.newGroup = function(){
    var body = '<label class="reg-label">اسم المجموعة</label><input class="reg-input" id="grpName" placeholder="مجموعة الأصدقاء"/>';
    body += '<label class="reg-label">الأعضاء</label><div class="list" id="grpMembers">';
    S.get().contacts.forEach(function(c){
      body += '<label class="list-item" style="cursor:pointer"><input type="checkbox" value="'+c.id+'" style="width:18px"/> '+avatarHTML(c,'sm')+'<div class="li-body"><div class="li-name">'+c.name+'</div></div></label>';
    });
    body += '</div>';
    modal({title:"مجموعة جديدة", body:body, foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button><button class="btn-primary neon" onclick="LOYEDUI.createGroup()">إنشاء</button>'});
  };
  SCREENS.createGroup = function(){
    var name=document.getElementById("grpName").value.trim()||"مجموعة";
    var ids=Array.from(document.querySelectorAll("#grpMembers input:checked")).map(function(i){return i.value;});
    var st=S.get();
    var chat={id:"c"+Date.now(),kind:"group",name:name,members:["me"].concat(ids),admins:["me"],pinned:false,muted:false,unread:0,messages:[]};
    st.chats.unshift(chat); S.save(); closeModal(); openChat(chat.id);
    toast("تم إنشاء المجموعة 💜");
  };

  SCREENS.newChannel = function(){
    var body='<label class="reg-label">اسم القناة</label><input class="reg-input" id="chName" placeholder="LOYED News"/>';
    body+='<label class="reg-label">الوصف</label><input class="reg-input" id="chDesc" placeholder="قناة رسمية"/>';
    modal({title:"قناة جديدة",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button><button class="btn-primary neon" onclick="LOYEDUI.createChannel()">إنشاء</button>'});
  };
  SCREENS.createChannel = function(){
    var name=document.getElementById("chName").value.trim()||"قناتي";
    var desc=document.getElementById("chDesc").value.trim();
    var st=S.get();
    var chat={id:"c"+Date.now(),kind:"channel",name:name,desc:desc,subscribers:0,verified:false,pinned:false,muted:false,unread:0,messages:[]};
    st.chats.unshift(chat); S.save(); closeModal(); openChat(chat.id);
    toast("تم إنشاء القناة 📢");
  };

  /* ---------- owner gate ---------- */
  SCREENS.openOwnerGate = function(){
    var dd=document.getElementById("topDropdown"); if(dd) dd.classList.remove("open");
    document.getElementById("ownerGate").classList.remove("hidden");
    setTimeout(function(){ var i=document.getElementById("ownerCodeInput"); if(i) i.focus(); }, 50);
  };
  SCREENS.cancelOwner = function(){
    document.getElementById("ownerGate").classList.add("hidden");
    document.getElementById("gateHint").textContent="";
    document.getElementById("ownerCodeInput").value="";
    document.getElementById("owner2faInput").value="";
  };
  SCREENS.verifyOwner = function(){
    var code=document.getElementById("ownerCodeInput").value;
    var fa=document.getElementById("owner2faInput").value;
    var hint=document.getElementById("gateHint");
    // Demo verification. In production: server-side HMAC verify, never compare in client.
    if(code !== "LO2009IED/YA2009HIA"){ hint.textContent="كود المالك غير صحيح."; return; }
    if(fa !== "000000" && fa.length!==6){ hint.textContent="أدخل رمز المصادقة الثنائية المكوّن من 6 أرقام (تجريبي: 000000)."; return; }
    hint.textContent="";
    S.t().ownerUnlocked=true;
    document.getElementById("ownerGate").classList.add("hidden");
    document.getElementById("ownerPanel").classList.remove("hidden");
    LOYEDOwner.render(document.getElementById("ownerPanel"));
    toast("مرحباً بك في OWNER CONTROL 👑");
  };

  /* ---------- STATUS ---------- */
  SCREENS.status = function(root){
    var st=S.get();
    var h=topbar(S.i18n("status"),{search:false,extra:'<button class="icon-btn" onclick="LOYEDUI.addStatus()">📷</button>'});
    h+='<div class="status-bar">';
    // my status
    h+='<div style="text-align:center;cursor:pointer" onclick="LOYEDUI.addStatus()"><div class="status-ring"><div class="avatar">'+S.initials(st.me.name)+'</div></div><div style="font-size:11px;margin-top:6px;color:var(--muted)">حالتي</div></div>';
    st.statuses.forEach(function(s){
      var u=S.findContact(s.userId);
      h+='<div style="text-align:center;cursor:pointer" onclick="LOYEDUI.viewStatus(\''+s.id+'\')"><div class="status-ring">'+avatarHTML(u)+'</div><div style="font-size:11px;margin-top:6px;color:var(--muted);max-width:60px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">'+u.name.split(" ")[0]+'</div></div>';
    });
    h+='</div>';
    h+='<div class="content"><div class="section-title">🔄 التحديثات الأخيرة</div><div class="list">';
    st.statuses.forEach(function(s){
      var u=S.findContact(s.userId);
      h+='<div class="list-item" onclick="LOYEDUI.viewStatus(\''+s.id+'\')">'+avatarHTML(u)+'<div class="li-body"><div class="li-name">'+u.name+'</div><div class="li-msg">'+escapeHTML(s.text)+'</div></div><div class="li-time">'+S.fmtTime(s.t)+'</div></div>';
    });
    h+='</div></div>';
    root.innerHTML=h;
  };
  SCREENS.addStatus = function(){
    var body='<label class="reg-label">نص الحالة</label><textarea class="reg-input" id="stText" rows="3" placeholder="ماذا يدور في ذهنك؟"></textarea>';
    body+='<label class="reg-label">من يستطيع المشاهدة</label><div class="seg"><button class="active">جهات الاتصال</button><button>الجميع</button><button>محددون</button></div>';
    modal({title:"حالة جديدة",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button><button class="btn-primary neon" onclick="LOYEDUI.postStatus()">نشر</button>'});
  };
  SCREENS.postStatus = function(){
    var txt=document.getElementById("stText").value.trim(); if(!txt){toast("اكتب نصاً");return;}
    var st=S.get();
    st.statuses.unshift({id:"s"+Date.now(),userId:"me",type:"text",text:txt,t:Date.now(),views:0});
    S.save(); closeModal(); navTo("status"); toast("تم نشر الحالة ✨");
  };
  SCREENS.viewStatus = function(id){
    var s=S.get().statuses.find(function(x){return x.id===id;});
    if(!s) return;
    var u=S.findContact(s.userId);
    s.views=(s.views||0)+1; S.save();
    var body='<div style="text-align:center;padding:20px">'+avatarHTML(u,'lg')+'<h3 style="margin:12px 0 4px">'+u.name+'</h3><div style="color:var(--muted);font-size:12px">'+S.fmtTime(s.t)+'</div><div style="background:var(--bg-2);border-radius:12px;padding:20px;margin:18px 0;font-size:17px">'+escapeHTML(s.text)+'</div><div style="color:var(--muted);font-size:13px">👁️ '+(s.views)+' مشاهدة</div></div>';
    modal({title:"حالة",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.replyStatus(\''+s.userId+'\')">رد</button><button class="btn-primary" onclick="LOYEDUI.closeModal()">إغلاق</button>'});
  };
  SCREENS.replyStatus = function(userId){ closeModal(); startDirect(userId); };

  /* ---------- CALLS ---------- */
  SCREENS.calls = function(root){
    var st=S.get();
    var h=topbar(S.i18n("calls"),{search:false,extra:'<button class="icon-btn" onclick="LOYEDUI.newCall()">📞</button>'});
    h+='<div class="content"><div class="list">';
    st.calls.forEach(function(cl){
      var u=S.findContact(cl.peer);
      var dirIcon = cl.missed ? '🚫' : (cl.dir==="in"?"↙️":"↗️");
      var dirCls = cl.missed?"miss":cl.dir;
      h+='<div class="call-item">'+avatarHTML(u)+'<div class="li-body"><div class="li-name">'+u.name+'</div><div class="call-type"><span class="call-dir '+dirCls+'">'+dirIcon+' '+(cl.type==="video"?"فيديو":"صوت")+' · '+S.fmtTime(cl.t)+'</span></div></div><button class="icon-btn" onclick="LOYEDUI.startCall(\''+cl.peer+'\',\''+cl.type+'\')">'+(cl.type==="video"?"🎥":"📞")+'</button></div>';
    });
    h+='</div></div>';
    root.innerHTML=h;
  };
  SCREENS.newCall = function(){
    var body='<div class="grid grid-2">';
    body+='<div class="tile" onclick="LOYEDUI.startCallPicker(\'voice\')"><div class="t-ico">📞</div><div class="t-name">مكالمة صوتية</div></div>';
    body+='<div class="tile" onclick="LOYEDUI.startCallPicker(\'video\')"><div class="t-ico">🎥</div><div class="t-name">مكالمة فيديو</div></div>';
    body+='</div><div class="section-title">جهات الاتصال</div><div class="list">';
    S.get().contacts.forEach(function(c){
      body+='<div class="list-item" onclick="LOYEDUI.startCall(\''+c.id+'\',\'voice\')">'+avatarHTML(c,'sm')+'<div class="li-body"><div class="li-name">'+c.name+'</div></div><button class="icon-btn">📞</button></div>';
    });
    body+='</div>';
    modal({title:"مكالمة جديدة",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button>'});
  };
  SCREENS.startCallPicker = function(type){
    toast("اختر جهة اتصال من القائمة");
  };
  SCREENS.startCall = function(peer, type){
    closeModal();
    var u=S.findContact(peer);
    var body='<div style="text-align:center;padding:30px 20px;min-height:300px;display:flex;flex-direction:column;justify-content:center;align-items:center">';
    body+=avatarHTML(u,'lg').replace("avatar lg","avatar lg");
    body+='<h3 style="margin:16px 0 4px">'+u.name+'</h3><div style="color:var(--muted);font-size:13px" id="callTimer">جارٍ الاتصال...</div>';
    body+='<div style="margin-top:30px;display:flex;gap:14px">';
    body+='<button class="icon-btn" style="width:54px;height:54px;background:var(--elev)">🔇</button>';
    if(type==="video") body+='<button class="icon-btn" style="width:54px;height:54px;background:var(--elev)">🎥</button>';
    body+='<button class="icon-btn" style="width:54px;height:54px;background:var(--elev)">🔊</button>';
    body+='<button class="btn-danger" style="width:54px;height:54px;border-radius:50%" onclick="LOYEDUI.endCall()">📵</button>';
    body+='</div></div>';
    modal({title:(type==="video"?"مكالمة فيديو":"مكالمة صوتية"),body:body});
    // simulate connecting -> connected
    window.__callStart = Date.now();
    window.__callTimer = setInterval(function(){
      var el=document.getElementById("callTimer"); if(!el){clearInterval(window.__callTimer);return;}
      var sec=Math.floor((Date.now()-window.__callStart)/1000);
      el.textContent = (sec<3?"جارٍ الاتصال...":"متصل · "+String(Math.floor(sec/60)).padStart(2,"0")+":"+String(sec%60).padStart(2,"0"));
    },1000);
  };
  SCREENS.endCall = function(){
    clearInterval(window.__callTimer);
    closeModal(); toast("تم إنهاء المكالمة");
  };

  /* ---------- MORE ---------- */
  SCREENS.more = function(root){
    var st=S.get();
    var h=topbar(S.i18n("more"),{search:false});
    h+='<div class="content"><div class="grid grid-3">';
    var tiles=[
      {id:"academy",ico:"🎓",name:"LOYED Academy",sub:"غرف تعليمية"},
      {id:"bots",ico:"🤖",name:"LOYED Bot Studio",sub:"إنشاء وإدارة البوتات",feat:"feat_bots"},
      {id:"store",ico:"🛍️",name:"LOYED Store",sub:"ثيمات وملصقات"},
      {id:"cloud",ico:"☁️",name:"LOYED Cloud",sub:"تخزين سحابي",feat:"feat_cloud"},
      {id:"live",ico:"📡",name:"LOYED Live",sub:"بث مباشر",feat:"feat_live"},
      {id:"gaming",ico:"🎮",name:"LOYED Gaming",sub:"ألعاب اجتماعية"},
      {id:"ai",ico:"✨",name:"LOYED AI",sub:"مساعد ذكي",feat:"feat_ai"},
      {id:"translate",ico:"🌐",name:"الترجمة الذكية",sub:"ترجمة فورية",feat:"feat_translate"},
      {id:"stickers",ico:"😀",name:"ملصقات وإيموجي",sub:"كيبورد LOYED"},
    ];
    tiles.forEach(function(t){
      var locked=false;
      if(t.feat){ var f=st.features.find(function(x){return x.id===t.feat;}); if(f && (!f.enabled || f.status==="paid" && st.me.plan!=="pro")) locked=true; }
      h+='<div class="tile'+(locked?' locked':'')+'" onclick="LOYEDUI.openMore(\''+t.id+'\','+(locked?"true":"false")+','+(t.feat?"'"+t.feat+"'":"null")+')"><div class="t-ico">'+t.ico+'</div><div class="t-name">'+t.name+'</div><div class="t-sub">'+t.sub+'</div></div>';
    });
    h+='</div>';
    h+='<div class="section-title">⚡ وصول سريع</div><div class="grid grid-2">';
    h+='<div class="card" onclick="LOYEDUI.navTo(\'settings\')"><h3>⚙️ الإعدادات</h3><p>الخصوصية، الثيمات، اللغات، الأمان</p></div>';
    h+='<div class="card" onclick="LOYEDUI.navTo(\'profile\')"><h3>👤 الملف الشخصي</h3><p>اسمك، معرفك، حالتك</p></div>';
    h+='</div></div>';
    root.innerHTML=h;
  };
  SCREENS.openMore = function(id, locked, feat){
    if(locked){
      var st=S.get();
      var f=st.features.find(function(x){return x.id===feat;});
      var body='<div style="text-align:center;padding:20px"><div style="font-size:48px">🔒</div><h3 style="margin:14px 0 8px">هذه الميزة تتطلب اشتراكًا لتفعيلها.</h3><p style="color:var(--muted)">'+(f?f.name:"")+'</p>';
      if(f && f.price) body+='<p style="margin-top:8px">السعر: $'+f.price+' / شهرياً</p>';
      body+='</div>';
      var foot='<button class="btn-ghost" onclick="LOYEDUI.closeModal()">لاحقاً</button><button class="btn-primary neon" onclick="LOYEDUI.requestFeature(\''+feat+'\')">طلب الاشتراك</button>';
      modal({title:"اشتراك مطلوب",body:body,foot:foot});
      return;
    }
    if(MORE_SCREENS[id]) MORE_SCREENS[id](); else toast("قريباً ✨");
  };
  SCREENS.requestFeature = function(feat){
    var req=S.addSubscriptionRequest("me", feat);
    closeModal();
    toast("تم إرسال طلب الاشتراك إلى المالك ✅");
  };

  /* ---------- PROFILE ---------- */
  SCREENS.profile = function(root){
    var st=S.get(); var me=st.me;
    var h=topbar("الملف الشخصي",{search:false});
    h+='<div class="content-pad"><div class="profile-head">';
    h+='<div class="avatar lg" style="background:'+S.avatarColor(me.avatarColor)+'">'+S.initials(me.name)+'</div>';
    h+='<div><div class="ph-name">'+me.name+'</div><div class="ph-id">'+me.loyedId+'</div>';
    h+='<div class="ph-phone">'+(me.phoneHidden?"🔒 رقم الهاتف مخفي":me.phone)+'</div></div></div>';
    h+='<div class="set-section">';
    h+='<div class="set-row" onclick="LOYEDUI.editName()"><span class="sr-ico">✏️</span><div class="sr-body"><div class="sr-title">الاسم</div><div class="sr-sub">'+me.name+'</div></div><span class="sr-val">›</span></div>';
    h+='<div class="set-row" onclick="LOYEDUI.editAbout()"><span class="sr-ico">📝</span><div class="sr-body"><div class="sr-title">النبذة</div><div class="sr-sub">'+me.about+'</div></div><span class="sr-val">›</span></div>';
    h+='<div class="set-row"><span class="sr-ico">🆔</span><div class="sr-body"><div class="sr-title">LOYED ID</div><div class="sr-sub">'+me.loyedId+'</div></div><span class="sr-val">نسخ</span></div>';
    h+='<div class="set-row" onclick="LOYEDUI.navTo(\'settings\')"><span class="sr-ico">🔒</span><div class="sr-body"><div class="sr-title">إخفاء رقم الهاتف</div><div class="sr-sub">'+(me.phoneHidden?"مفعّل":"غير مفعّل")+'</div></div><span class="sr-val">›</span></div>';
    h+='</div>';
    // statuses
    h+='<div class="set-section"><h2>الحالة</h2>';
    h+='<div class="set-row"><span class="sr-ico"><span class="dot '+me.status+'"></span></span><div class="sr-body"><div class="sr-title">حالتي الحالية</div><div class="sr-sub">'+statusLabel(me.status)+'</div></div></div>';
    h+='<div class="seg">';
    ["online","offline","busy","dnd"].forEach(function(s){
      h+='<button class="'+(me.status===s?'active':'')+'" onclick="LOYEDUI.setStatus(\''+s+'\')">'+statusLabel(s)+'</button>';
    });
    h+='</div></div>';
    // plan
    h+='<div class="set-section"><h2>الاشتراك</h2><div class="set-row"><span class="sr-ico">⭐</span><div class="sr-body"><div class="sr-title">الخطة الحالية</div><div class="sr-sub">'+(me.plan==="pro"?"LOYED Pro 💜":"مجاني")+'</div></div></div></div>';
    h+='<button class="btn-ghost" style="width:100%;margin-top:10px" onclick="LOYEDUI.logout()">تسجيل الخروج</button>';
    h+='</div>';
    root.innerHTML=h;
  };
  function statusLabel(s){return {online:"متصل الآن",offline:"غير متصل",busy:"مشغول",dnd:"عدم الإزعاج"}[s]||s;}
  SCREENS.setStatus = function(s){ S.setMe({status:s}); navTo("profile"); };
  SCREENS.editName = function(){
    var body='<label class="reg-label">الاسم</label><input class="reg-input" id="edName" value="'+S.get().me.name+'"/>';
    modal({title:"تعديل الاسم",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button><button class="btn-primary neon" onclick="LOYEDUI.saveName()">حفظ</button>'});
  };
  SCREENS.saveName = function(){ var v=document.getElementById("edName").value.trim(); if(v){S.setMe({name:v}); document.getElementById("meAvatarMini").textContent=S.initials(v);} closeModal(); navTo("profile"); };
  SCREENS.editAbout = function(){
    var body='<label class="reg-label">النبذة</label><input class="reg-input" id="edAbout" value="'+S.get().me.about+'"/>';
    modal({title:"تعديل النبذة",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button><button class="btn-primary neon" onclick="LOYEDUI.saveAbout()">حفظ</button>'});
  };
  SCREENS.saveAbout = function(){ var v=document.getElementById("edAbout").value.trim(); if(v)S.setMe({about:v}); closeModal(); navTo("profile"); };
  SCREENS.logout = function(){
    if(confirm("تسجيل الخروج سيؤدي لمسح البيانات المحلية (التجريبية). متابعة؟")){ S.reset(); location.reload(); }
  };

  /* ---------- SETTINGS ---------- */
  SCREENS.settings = function(root){
    var st=S.get(); var me=st.me;
    var h=topbar(S.i18n("settings"),{search:false});
    h+='<div class="content-pad">';

    // appearance
    h+='<div class="set-section"><h2>🎨 المظهر والثيمات</h2>';
    var themes=[["cyberpunk","Cyberpunk","🌃"],["stealth","Stealth","🥷"],["galaxy","Galaxy","🌌"],["neon","Purple Neon","💜"],["classic","Classic Dark","⬛"],["light","Light","☀️"]];
    h+='<div class="grid grid-3">';
    themes.forEach(function(t){
      h+='<div class="tile'+(me.theme===t[0]?'':'')+'" style="'+(me.theme===t[0]?'border-color:var(--accent);box-shadow:var(--glow)':'')+'" onclick="LOYEDUI.applyTheme(\''+t[0]+'\')"><div class="t-ico">'+t[1]+'</div><div class="t-name">'+t[2]+'</div></div>';
    });
    h+='</div></div>';

    // language
    h+='<div class="set-section"><h2>🌐 اللغة</h2><div class="set-row"><span class="sr-ico">🌐</span><div class="sr-body"><div class="sr-title">لغة الواجهة</div><div class="sr-sub">'+currentLangName()+'</div></div><span class="sr-val" onclick="LOYEDUI.pickLang()">›</span></div></div>';

    // privacy
    h+='<div class="set-section"><h2>🔒 الخصوصية</h2>';
    h+=privacyRow("إظهار رقم الهاتف","phoneVisibility",me.phoneVisibility,[["everyone","للجميع"],["contacts","جهات الاتصال فقط"],["nobody","إخفاء عن الجميع"]]);
    h+=privacyRow("آخر ظهور","lastSeen",me.lastSeen||"contacts",[["everyone","الجميع"],["contacts","جهات الاتصال"],["nobody","لا أحد"]]);
    h+=privacyRow("صورة الملف الشخصي","profilePhoto",me.profilePhoto||"contacts",[["everyone","الجميع"],["contacts","جهات الاتصال"],["nobody","لا أحد"]]);
    h+=privacyRow("الحالات اليومية","statusPrivacy",me.statusPrivacy||"contacts",[["everyone","الجميع"],["contacts","جهات الاتصال"],["nobody","لا أحد"]]);
    h+='<div class="set-row" onclick="LOYEDUI.toast(\'قريباً\')"><span class="sr-ico">🚫</span><div class="sr-body"><div class="sr-title">المستخدمون المحظورون</div><div class="sr-sub">0 محظور</div></div><span class="sr-val">›</span></div>';
    h+='<div class="set-row" onclick="LOYEDUI.toast(\'قريباً\')"><span class="sr-ico">👥</span><div class="sr-body"><div class="sr-title">من يضيفني للمجموعات</div><div class="sr-sub">جهات الاتصال</div></div><span class="sr-val">›</span></div>';
    h+='</div>';

    // security
    h+='<div class="set-section"><h2>🛡️ الأمان</h2>';
    h+=switchRow("قفل التطبيق","appLock",me.appLock);
    h+=switchRow("المصادقة الثنائية","twoFA",me.twoFA);
    h+=switchRow("تنبيهات تسجيل الدخول","loginAlerts",me.loginAlerts!==false);
    h+='<div class="set-row" onclick="LOYEDUI.toast(\'3 أجهزة مرتبطة\')"><span class="sr-ico">📱</span><div class="sr-body"><div class="sr-title">الأجهزة المرتبطة</div><div class="sr-sub">إدارة الجلسات</div></div><span class="sr-val">›</span></div>';
    h+='<div class="set-row" onclick="LOYEDUI.toast(\'تم تسجيل الخروج من باقي الأجهزة\')"><span class="sr-ico">🚪</span><div class="sr-body"><div class="sr-title">تسجيل الخروج من كل الأجهزة</div></div><span class="sr-val">›</span></div>';
    h+='</div>';

    // notifications
    h+='<div class="set-section"><h2>🔔 الإشعارات</h2>';
    h+=switchRow("إشعارات الرسائل","notifMsg",me.notifMsg!==false);
    h+=switchRow("إشعارات المكالمات","notifCall",me.notifCall!==false);
    h+=switchRow("إشعارات الردود والتفاعلات","notifReactions",me.notifReactions);
    h+=switchRow("تنبيهات أمنية","notifSecurity",me.notifSecurity!==false);
    h+='</div>';

    // chat
    h+='<div class="set-section"><h2>💬 المحادثات</h2>';
    h+=switchRow("إيصالات القراءة","readReceipts",me.readReceipts!==false);
    h+='<div class="set-row"><span class="sr-ico">⏱️</span><div class="sr-body"><div class="sr-title">الرسائل المؤقتة</div><div class="sr-sub">إيقاف</div></div><span class="sr-val">›</span></div>';
    h+='<div class="set-row"><span class="sr-ico">🔤</span><div class="sr-body"><div class="sr-title">حجم الخط</div><div class="sr-sub">متوسط</div></div><span class="sr-val">›</span></div>';
    h+='</div>';

    // about
    h+='<div class="set-section"><h2>ℹ️ حول LOYED</h2><div class="card"><h3>LOYED v'+st.app.version+'</h3><p>'+st.app.tagline+'</p><p style="margin-top:8px;color:var(--neon)">'+st.app.subTagline+'</p></div></div>';
    h+='</div>';
    root.innerHTML=h;
  };

  function privacyRow(title,key,val,opts){
    var h='<div class="set-row" onclick="LOYEDUI.pickPrivacy(\''+key+'\',\''+title+'\')"><span class="sr-ico">🔒</span><div class="sr-body"><div class="sr-title">'+title+'</div></div><span class="sr-val">'+(opts.find(function(o){return o[0]===val;})||opts[1])[1]+' ›</span></div>';
    return h;
  }
  function switchRow(title,key,checked){
    return '<div class="set-row"><span class="sr-ico">⚙️</span><div class="sr-body"><div class="sr-title">'+title+'</div></div><label class="switch"><input type="checkbox" '+(checked?'checked':'')+' onchange="LOYEDUI.toggleSet(\''+key+'\',this.checked)"/><span class="slider"></span></label></div>';
  }
  SCREENS.toggleSet = function(key,val){ var p={}; p[key]=val; S.setMe(p); toast("تم الحفظ ✓"); };
  SCREENS.applyTheme = function(t){ S.setTheme(t); navTo("settings"); toast("تم تطبيق الثيم ✨"); };

  function currentLangName(){
    var st=S.get(); var l=st.languages.find(function(x){return x.code===st.me.lang;}); return l?l.native:"العربية";
  }
  SCREENS.pickLang = function(){
    var st=S.get();
    var body='<div class="list" style="max-height:400px;overflow-y:auto">';
    st.languages.forEach(function(l){
      body+='<div class="list-item" onclick="LOYEDUI.setLangUI(\''+l.code+'\')"><span style="font-size:22px">'+l.flag+'</span><div class="li-body"><div class="li-name">'+l.native+'</div><div class="li-msg">'+l.name+'</div></div>'+(st.me.lang===l.code?'<span class="tick read">✓</span>':'')+'</div>';
    });
    body+='</div>';
    modal({title:"اختر اللغة",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button>'});
  };
  SCREENS.setLangUI = function(code){ S.setLang(code); closeModal(); navTo("settings"); toast("تم تغيير اللغة 🌐"); };

  SCREENS.pickPrivacy = function(key,title){
    var optsMap={
      phoneVisibility:[["everyone","للجميع"],["contacts","جهات الاتصال فقط"],["nobody","إخفاء عن الجميع"]],
      lastSeen:[["everyone","الجميع"],["contacts","جهات الاتصال"],["nobody","لا أحد"]],
      profilePhoto:[["everyone","الجميع"],["contacts","جهات الاتصال"],["nobody","لا أحد"]],
      statusPrivacy:[["everyone","الجميع"],["contacts","جهات الاتصال"],["nobody","لا أحد"]],
    };
    var opts=optsMap[key]||[];
    var body='<div class="list">';
    opts.forEach(function(o){
      body+='<div class="list-item" onclick="LOYEDUI.setPrivacy(\''+key+'\',\''+o[0]+'\')"><div class="li-body"><div class="li-name">'+o[1]+'</div></div></div>';
    });
    body+='</div>';
    modal({title:title,body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button>'});
  };
  SCREENS.setPrivacy = function(key,val){
    var p={}; p[key]=val;
    if(key==="phoneVisibility"){ p.phoneHidden = (val!=="everyone"); }
    S.setMe(p); closeModal(); navTo("settings"); toast("تم تحديث الخصوصية 🔒");
  };

  /* ---------- escape ---------- */
  function escapeHTML(s){ if(s==null)return""; return String(s).replace(/[&<>"']/g,function(c){return {"&":"&amp;","<":"&lt;",">":"&gt;","\"":"&quot;","'":"&#39;"}[c];}); }

  // expose
  return {
    boot:boot, navTo:navTo, toast:toast, modal:modal, closeModal:closeModal,
    openChat:null, refreshChatTicks:null,
    chatTab:SCREENS.chatTab, newChatFab:SCREENS.newChatFab, startDirect:SCREENS.startDirect,
    newGroup:SCREENS.newGroup, createGroup:SCREENS.createGroup, newChannel:SCREENS.newChannel, createChannel:SCREENS.createChannel,
    openOwnerGate:SCREENS.openOwnerGate, cancelOwner:SCREENS.cancelOwner, verifyOwner:SCREENS.verifyOwner,
    addStatus:SCREENS.addStatus, postStatus:SCREENS.postStatus, viewStatus:SCREENS.viewStatus, replyStatus:SCREENS.replyStatus,
    newCall:SCREENS.newCall, startCallPicker:SCREENS.startCallPicker, startCall:SCREENS.startCall, endCall:SCREENS.endCall,
    openMore:SCREENS.openMore, requestFeature:SCREENS.requestFeature,
    editName:SCREENS.editName, saveName:SCREENS.saveName, editAbout:SCREENS.editAbout, saveAbout:SCREENS.saveAbout, logout:SCREENS.logout,
    setStatus:SCREENS.setStatus, applyTheme:SCREENS.applyTheme, pickLang:SCREENS.pickLang, setLangUI:SCREENS.setLangUI,
    pickPrivacy:SCREENS.pickPrivacy, setPrivacy:SCREENS.setPrivacy, toggleSet:SCREENS.toggleSet,
    filterList:filterList, avatarHTML:avatarHTML, tickHTML:tickHTML, escapeHTML:escapeHTML,
  };
})();

/* ---------- MORE screens (AI, Bots, Store, Cloud, Academy, Live, Gaming, Translate, Stickers) ---------- */
var MORE_SCREENS = {}; // filled in chat.js / app.js below

/* ---------- boot ---------- */
if(document.readyState==="loading"){
  document.addEventListener("DOMContentLoaded", function(){ LOYEDUI.boot(); });
} else {
  LOYEDUI.boot();
}

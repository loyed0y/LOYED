/* ============================================================
   LOYED — chat conversation view + servers + social + more screens
   ============================================================ */
(function(){
  var S = LOYEDStore;
  var UI = LOYEDUI;
  var currentChatId = null;
  var replyTo = null;

  /* ---------- OPEN CHAT ---------- */
  UI.openChat = function(chatId){
    currentChatId = chatId;
    replyTo = null;
    S.markRead(chatId);
    var chat = S.findChat(chatId);
    if(!chat) return;
    renderChatView(chat);
    document.getElementById("chatView").classList.remove("hidden");
    UI.navTo("chats"); // keep rail on chats
  };

  function chatTitle(chat){
    if(chat.kind==="direct"){ var p=S.findContact(chat.peer); return {name:p.name, sub:statusLine(p), avatar:UI.avatarHTML(p)}; }
    if(chat.kind==="group") return {name:chat.name, sub:(chat.members?chat.members.length:0)+" عضو", avatar:'<div class="avatar group">👥</div>'};
    if(chat.kind==="channel") return {name:chat.name+(chat.verified?' <span style="color:var(--accent)">✔</span>':""), sub:(chat.subscribers||0)+" مشترك", avatar:'<div class="avatar channel">📢</div>'};
    return {name:"محادثة",sub:"",avatar:'<div class="avatar">💬</div>'};
  }
  function statusLine(p){
    if(p.online) return "متصل الآن";
    return S.fmtLastSeen(p.lastSeen);
  }

  function renderChatView(chat){
    var t = chatTitle(chat);
    var v = document.getElementById("chatView");
    var h = '<div class="cv-top">';
    h += '<button class="cv-back icon-btn" onclick="LOYEDUI.closeChat()">›</button>';
    h += t.avatar.replace('class="avatar','class="avatar sm').replace("avatar lg","avatar sm");
    h += '<div class="cv-grow"><div class="cv-name">'+t.name+'</div><div class="cv-status">'+t.sub+'</div></div>';
    h += '<button class="cv-ico" onclick="LOYEDUI.startCall(\''+(chat.peer||"")+'\',\'voice\')">📞</button>';
    h += '<button class="cv-ico" onclick="LOYEDUI.startCall(\''+(chat.peer||"")+'\',\'video\')">🎥</button>';
    h += '<button class="cv-ico" onclick="LOYEDUI.chatMenu(\''+chat.id+'\')">⋮</button>';
    h += '</div>';
    h += '<div class="cv-body" id="cvBody">';
    h += '<div class="cv-date-sep">اليوم</div>';
    if(chat.messages && chat.messages.length){
      chat.messages.forEach(function(m){ h += bubbleHTML(chat, m); });
    } else {
      h += '<div class="empty"><div class="em-ico">💬</div>ابدأ المحادثة — أرسل أول رسالة</div>';
    }
    h += '</div>';
    // typing
    h += '<div class="typing-ind" id="typingInd" style="display:none"><span class="typing-dots"><span></span><span></span><span></span></span> يكتب الآن...</div>';
    // composer
    var canSend = (chat.kind!=="channel");
    h += '<div class="cv-composer">';
    if(canSend){
      h += '<button class="cv-ico" onclick="LOYEDUI.openEmoji()">😊</button>';
      h += '<button class="cv-ico" onclick="LOYEDUI.attachMenu()">📎</button>';
    }
    h += '<textarea class="cv-input" id="cvInput" placeholder="'+(canSend?"اكتب رسالة...":"يمكنك فقط المتابعة")+'" '+(canSend?"":"disabled")+' onkeydown="LOYEDUI.onComposerKey(event)"></textarea>';
    if(canSend) h += '<button class="cv-ico cv-send" onclick="LOYEDUI.sendCurrent()">➤</button>';
    h += '</div>';
    v.innerHTML = h;
    scrollChatBottom();
    if(canSend) document.getElementById("cvInput").focus();
  }

  function bubbleHTML(chat, m){
    var mine = (m.from==="me");
    var fromName = "";
    if(chat.kind==="group" && !mine){ var u=S.findContact(m.from); fromName = '<div style="font-size:11px;color:var(--neon);font-weight:700;margin-bottom:2px">'+u.name+'</div>'; }
    var replyHTML = "";
    if(m.replyTo){
      var rm = chat.messages.find(function(x){return x.id===m.replyTo;});
      if(rm){ var ru=S.findContact(rm.from); replyHTML='<div class="b-reply-quote">'+(ru.name||"")+': '+UI.escapeHTML(rm.text)+'</div>'; }
    }
    var edited = m.edited?'<span style="opacity:.6"> ~معدّلة</span>':"";
    var meta = '<div class="b-meta">'+edited+'<span>'+S.fmtTime(m.t)+'</span>'+UI.tickHTML(m.status)+'</div>';
    var reacts = "";
    if(m.reactions){ reacts='<div class="reactions">'; m.reactions.forEach(function(r){ reacts+='<span class="reaction">'+r.e+' '+r.n+'</span>'; }); reacts+='</div>'; }
    return '<div class="bubble '+(mine?"me":"them")+(m.replyTo?" replied":"")+'" oncontextmenu="LOYEDUI.msgMenu(\''+chat.id+'\',\''+m.id+'\');return false" onclick="LOYEDUI.msgTap(\''+chat.id+'\',\''+m.id+'\')">'+fromName+replyHTML+'<div>'+UI.escapeHTML(m.text)+'</div>'+reacts+meta+'</div>';
  }

  UI.closeChat = function(){
    document.getElementById("chatView").classList.add("hidden");
    currentChatId = null;
    UI.navTo("chats");
  };

  UI.refreshChatTicks = function(chatId, msgId){
    if(currentChatId!==chatId) return;
    var bubble = document.querySelector('.bubble[data-mid="'+msgId+'"]');
    if(!bubble){
      // re-render to update meta
      var chat=S.findChat(chatId); if(chat) renderChatView(chat);
      return;
    }
  };

  function scrollChatBottom(){
    var b=document.getElementById("cvBody"); if(b) b.scrollTop=b.scrollHeight;
  }

  UI.onComposerKey = function(e){
    if(e.key==="Enter" && !e.shiftKey){ e.preventDefault(); UI.sendCurrent(); }
  };

  UI.sendCurrent = function(){
    var inp=document.getElementById("cvInput"); if(!inp) return;
    var text=inp.value.trim(); if(!text) return;
    var msg=S.sendMsg(currentChatId, text);
    if(replyTo && msg){ msg.replyTo=replyTo; S.save(); replyTo=null; }
    inp.value="";
    var chat=S.findChat(currentChatId); renderChatView(chat);
    // simulate auto-reply for direct chats
    if(chat.kind==="direct" && !S.findContact(chat.peer).isBot){
      setTimeout(function(){
        var ti=document.getElementById("typingInd"); if(ti) ti.style.display="block";
        setTimeout(function(){
          if(ti) ti.style.display="none";
          S.sendMsg(currentChatId, pickReply(), chat.peer);
          var c=S.findChat(currentChatId); if(currentChatId===c.id) renderChatView(c);
        }, 1400);
      }, 800);
    } else if(chat.kind==="direct" && S.findContact(chat.peer).isBot){
      setTimeout(function(){
        S.sendMsg(currentChatId, "🤖 بوت LOYED: تم استلام رسالتك، سأرد قريباً.", chat.peer);
        var c=S.findChat(currentChatId); if(currentChatId===c.id) renderChatView(c);
      }, 700);
    }
  };

  function pickReply(){
    var r=["تمام 👍","أوكي خلاص","حاضر، تحت أمرك","أكيد؟","هاها 😄","تمام نكمل كلام بعد شوية","👍👍"];
    return r[Math.floor(Math.random()*r.length)];
  }

  /* ---------- message menu ---------- */
  UI.msgTap = function(chatId,msgId){
    // on desktop, contextmenu handles it; tap also opens
    UI.msgMenu(chatId,msgId);
  };
  UI.msgMenu = function(chatId,msgId){
    var chat=S.findChat(chatId); var m=chat.messages.find(function(x){return x.id===msgId;});
    var mine=(m.from==="me");
    var items=[
      {label:"رد",ico:"↩️",onclick:"LOYEDUI.replyMsg('"+chatId+"','"+msgId+"')"},
      {label:"تفاعل",ico:"❤️",onclick:"LOYEDUI.reactMsg('"+chatId+"','"+msgId+"')"},
      {label:"نسخ",ico:"📋",onclick:"LOYEDUI.copyMsg('"+chatId+"','"+msgId+"')"},
      {label:"إعادة توجيه",ico:"➡️",onclick:"LOYEDUI.forwardMsg('"+chatId+"','"+msgId+"')"},
      {label:"تثبيت",ico:"📌",onclick:"LOYEDUI.toast('تم التثبيت')"},
      {label:"تمييز كمهم",ico:"⭐",onclick:"LOYEDUI.toast('تم التمييز')"},
    ];
    if(mine){
      items.push({label:"تعديل",ico:"✏️",onclick:"LOYEDUI.editMsgUI('"+chatId+"','"+msgId+"')"});
      items.push({divider:true});
      items.push({label:"حذف لدى الطرفين",ico:"🗑️",danger:true,onclick:"LOYEDUI.delMsgUI('"+chatId+"','"+msgId+"',true)"});
    } else {
      items.push({divider:true});
      items.push({label:"حذف لديّ",ico:"🗑️",danger:true,onclick:"LOYEDUI.delMsgUI('"+chatId+"','"+msgId+"',false)"});
    }
    var body='<div class="list">';
    items.forEach(function(it){
      if(it.divider){body+='<div class="dropdown-divider"></div>';return;}
      body+='<button class="dropdown-item'+(it.danger?' danger':'')+'" style="width:100%" onclick="'+it.onclick+';LOYEDUI.closeModal()"><span class="di-ico">'+it.ico+'</span>'+it.label+'</button>';
    });
    body+='</div>';
    UI.modal({title:"خيارات الرسالة",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button>'});
  };

  UI.replyMsg = function(chatId,msgId){
    replyTo=msgId; UI.closeModal();
    var inp=document.getElementById("cvInput"); if(inp){inp.focus(); inp.placeholder="رد على الرسالة...";}
  };
  UI.reactMsg = function(chatId,msgId){
    var chat=S.findChat(chatId); var m=chat.messages.find(function(x){return x.id===msgId;});
    var emojis=["❤️","😂","👍","🔥","😮","😢","🙏"];
    var body='<div class="emoji-pal">';
    emojis.forEach(function(e){ body+='<button onclick="LOYEDUI.doReact(\''+chatId+'\',\''+msgId+'\',\''+e+'\')">'+e+'</button>'; });
    body+='</div>';
    UI.modal({title:"تفاعل",body:body});
  };
  UI.doReact = function(chatId,msgId,e){
    var chat=S.findChat(chatId); var m=chat.messages.find(function(x){return x.id===msgId;});
    if(!m.reactions) m.reactions=[];
    var ex=m.reactions.find(function(r){return r.e===e;});
    if(ex) ex.n++; else m.reactions.push({e:e,n:1});
    S.save(); UI.closeModal(); renderChatView(chat);
  };
  UI.copyMsg = function(chatId,msgId){
    var chat=S.findChat(chatId); var m=chat.messages.find(function(x){return x.id===msgId;});
    try{ navigator.clipboard.writeText(m.text); }catch(e){}
    UI.closeModal(); UI.toast("تم النسخ 📋");
  };
  UI.forwardMsg = function(chatId,msgId){
    var chat=S.findChat(chatId); var m=chat.messages.find(function(x){return x.id===msgId;});
    var st=S.get();
    var body='<div class="list">';
    st.chats.forEach(function(c){
      var name=c.kind==="direct"?S.findContact(c.peer).name:c.name;
      body+='<div class="list-item" onclick="LOYEDUI.doForward(\''+chatId+'\',\''+msgId+'\',\''+c.id+'\')">'+(c.kind==="direct"?UI.avatarHTML(S.findContact(c.peer),"sm"):'<div class="avatar sm group">👥</div>')+'<div class="li-body"><div class="li-name">'+name+'</div></div></div>';
    });
    body+='</div>';
    UI.modal({title:"إعادة توجيه إلى",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button>'});
  };
  UI.doForward = function(fromChat,msgId,toChat){
    var fc=S.findChat(fromChat); var m=fc.messages.find(function(x){return x.id===msgId;});
    S.sendMsg(toChat, m.text, "me");
    UI.closeModal(); UI.toast("تمت إعادة التوجيه ➡️");
  };
  UI.editMsgUI = function(chatId,msgId){
    var chat=S.findChat(chatId); var m=chat.messages.find(function(x){return x.id===msgId;});
    var body='<label class="reg-label">تعديل الرسالة</label><textarea class="reg-input" id="editMsgTxt" rows="3">'+m.text+'</textarea>';
    UI.modal({title:"تعديل الرسالة",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button><button class="btn-primary neon" onclick="LOYEDUI.doEditMsg(\''+chatId+'\',\''+msgId+'\')">حفظ</button>'});
  };
  UI.doEditMsg = function(chatId,msgId){
    var v=document.getElementById("editMsgTxt").value.trim();
    if(v){ S.editMsg(chatId,msgId,v); UI.closeModal(); var c=S.findChat(chatId); renderChatView(c); }
  };
  UI.delMsgUI = function(chatId,msgId,both){
    S.deleteMsg(chatId,msgId,both);
    UI.closeModal();
    var c=S.findChat(chatId); renderChatView(c);
    UI.toast(both?"تم الحذف لدى الطرفين 🗑️":"تم الحذف لديّ 🗑️");
  };

  UI.chatMenu = function(chatId){
    var chat=S.findChat(chatId);
    var items=[
      {label:chat.pinned?"إلغاء التثبيت":"تثبيت المحادثة",ico:"📌",onclick:"LOYEDUI.togglePinChat('"+chatId+"')"},
      {label:chat.muted?"إلغاء الكتم":"كتم الإشعارات",ico:"🔕",onclick:"LOYEDUI.toggleMuteChat('"+chatId+"')"},
      {label:"بحث في المحادثة",ico:"🔍",onclick:"LOYEDUI.toast('قريباً')"},
      {label:"مشاركة الموقع",ico:"📍",onclick:"LOYEDUI.shareLocation('"+chatId+"')"},
      {label:"مشاركة جهة اتصال",ico:"👤",onclick:"LOYEDUI.shareContact('"+chatId+"')"},
      {label:"الرسائل المؤقتة",ico:"⏱️",onclick:"LOYEDUI.toast('قريباً')"},
      {label:"مسح المحادثة",ico:"🧹",danger:true,onclick:"LOYEDUI.clearChat('"+chatId+"')"},
    ];
    var body='<div class="list">';
    items.forEach(function(it){
      body+='<button class="dropdown-item'+(it.danger?' danger':'')+'" style="width:100%" onclick="'+it.onclick+';LOYEDUI.closeModal()"><span class="di-ico">'+it.ico+'</span>'+it.label+'</button>';
    });
    body+='</div>';
    UI.modal({title:"خيارات المحادثة",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button>'});
  };
  UI.togglePinChat = function(id){ S.togglePin(id); UI.closeModal(); UI.navTo("chats"); UI.toast("تم ✓"); };
  UI.toggleMuteChat = function(id){ var c=S.findChat(id); S.setChatMute(id,!c.muted); UI.closeModal(); UI.navTo("chats"); UI.toast("تم ✓"); };
  UI.clearChat = function(id){ var c=S.findChat(id); c.messages=[]; S.save(); UI.closeModal(); renderChatView(c); UI.toast("تم مسح المحادثة"); };
  UI.shareLocation = function(id){ S.sendMsg(id,"📍 تمت مشاركة الموقع (محاكاة)","me"); UI.closeModal(); var c=S.findChat(id); renderChatView(c); UI.toast("تمت مشاركة الموقع"); };
  UI.shareContact = function(id){
    var body='<div class="list">';
    S.get().contacts.forEach(function(c){ body+='<div class="list-item" onclick="LOYEDUI.doShareContact(\''+id+'\',\''+c.id+'\')">'+UI.avatarHTML(c,'sm')+'<div class="li-body"><div class="li-name">'+c.name+'</div><div class="li-msg">'+(c.loyedId||"")+'</div></div></div>'; });
    body+='</div>';
    UI.modal({title:"مشاركة جهة اتصال",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button>'});
  };
  UI.doShareContact = function(chatId,cid){
    var c=S.findContact(cid);
    S.sendMsg(chatId,"👤 تمت مشاركة جهة اتصال: "+c.name+" ("+c.loyedId+")","me");
    UI.closeModal(); var ch=S.findChat(chatId); renderChatView(ch);
  };

  UI.openEmoji = function(){
    var emojis=["😀","😂","🥰","😍","😎","🤔","😢","😡","👍","👎","❤️","🔥","✨","🎉","💜","💯","🙏","🚀","🌙","⭐"];
    var body='<div class="emoji-pal">';
    emojis.forEach(function(e){ body+='<button onclick="LOYEDUI.insertEmoji(\''+e+'\')">'+e+'</button>'; });
    body+='</div>';
    UI.modal({title:"إيموجي",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إغلاق</button>'});
  };
  UI.insertEmoji = function(e){
    var inp=document.getElementById("cvInput"); if(inp){ inp.value+=e; inp.focus(); }
  };
  UI.attachMenu = function(){
    var items=[
      {label:"صورة / فيديو",ico:"🖼️",onclick:"LOYEDUI.sendAttach('صورة')"},
      {label:"ملف / مستند",ico:"📄",onclick:"LOYEDUI.sendAttach('مستند')"},
      {label:"رسالة صوتية",ico:"🎤",onclick:"LOYEDUI.sendAttach('صوتي')"},
      {label:"فيديو قصير",ico:"🎬",onclick:"LOYEDUI.sendAttach('فيديو قصير')"},
    ];
    var body='<div class="list">';
    items.forEach(function(it){ body+='<button class="dropdown-item" style="width:100%" onclick="'+it.onclick+';LOYEDUI.closeModal()"><span class="di-ico">'+it.ico+'</span>'+it.label+'</button>'; });
    body+='</div>';
    UI.modal({title:"إرفاق",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button>'});
  };
  UI.sendAttach = function(kind){
    S.sendMsg(currentChatId,"["+kind+" — تجريبي]","me");
    UI.closeModal(); var c=S.findChat(currentChatId); renderChatView(c);
  };

  /* ============================================================
     SERVERS SCREEN (Discord-like)
     ============================================================ */
  LOYEDUI.navTo; // ensure
  // register servers/social as screens via app SCREENS injection
  // We attach to the SCREENS object through nav hook:
  var _origNav = UI.navTo;
  // We can't replace easily; instead register on a global map the app.js reads? 
  // app.js uses internal SCREENS. We add by extending through a custom event approach.
  // Simpler: define SCREENS extension object and patch navTo.

  // Patch navTo to route extra screens
  var EXTRA = {};
  UI.registerScreen = function(name, fn){ EXTRA[name]=fn; };
  var _realNav = UI.navTo;
  UI.navTo = function(name){
    if(EXTRA[name]){ 
      S.t().currentScreen=name;
      document.querySelectorAll(".rail-btn[data-nav]").forEach(function(b){b.classList.toggle("active", b.dataset.nav===name);});
      document.getElementById("railSettings").classList.remove("active");
      document.getElementById("mainArea").innerHTML="";
      EXTRA[name](document.getElementById("mainArea"));
      return;
    }
    _realNav(name);
  };

  /* SERVERS */
  UI.registerScreen("servers", function(root){
    var st=S.get();
    var h='<div class="topbar"><h1>LOYED Servers</h1><div class="tb-grow"></div><button class="icon-btn" onclick="LOYEDUI.toast(\'إنشاء سيرفر — تجريبي\')">＋</button></div>';
    h+='<div class="content"><div class="grid grid-2">';
    st.servers.forEach(function(sv){
      h+='<div class="card" onclick="LOYEDUI.openServer(\''+sv.id+'\')"><div class="row-flex"><div style="font-size:34px">'+sv.icon+'</div><div class="spacer"></div><span class="badge-soft">'+sv.members+'</span></div><h3 style="margin-top:8px">'+sv.name+'</h3><p>'+sv.channels.length+' قناة</p></div>';
    });
    h+='</div></div>';
    root.innerHTML=h;
  });
  UI.openServer = function(id){
    var sv=S.get().servers.find(function(x){return x.id===id;});
    var body='<div style="display:flex;gap:0;height:60vh">';
    body+='<div style="width:160px;background:var(--bg-2);border-inline-end:1px solid var(--border);padding:10px"><div style="font-weight:800;margin-bottom:8px">'+sv.icon+' '+sv.name+'</div>';
    sv.channels.forEach(function(ch){
      body+='<div style="padding:8px;border-radius:8px;cursor:pointer;font-size:13px;color:var(--muted)" onclick="LOYEDUI.toast(\'قناة '+ch.name+'\')">'+(ch.type==="voice"||ch.type==="stage"?"🔊":"#")+ch.name+(ch.users&&ch.users.length?' <span class="dot online"></span>':'')+'</div>';
    });
    body+='</div>';
    body+='<div style="flex:1;padding:14px"><div style="font-weight:700;font-size:16px;margin-bottom:10px"># general</div>';
    body+='<div style="background:var(--bg-2);border-radius:10px;padding:14px;color:var(--muted);font-size:13px">مرحباً بك في '+sv.name+'. ابدأ المحادثة! 💜</div>';
    body+='</div></div>';
    UI.modal({title:sv.name,body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إغلاق</button>'});
  };

  /* SOCIAL */
  UI.registerScreen("social", function(root){
    var st=S.get();
    var h='<div class="topbar"><h1>LOYED Social</h1><div class="tb-grow"></div><button class="icon-btn" onclick="LOYEDUI.newPost()">✎</button></div>';
    h+='<div class="content"><div class="section-title">📰 آخر المنشورات</div>';
    st.social.forEach(function(p){
      var u=S.findContact(p.userId);
      h+='<div class="card" style="margin-bottom:10px"><div class="row-flex">'+UI.avatarHTML(u,'sm')+'<div><div style="font-weight:700">'+u.name+'</div><div style="font-size:11px;color:var(--muted)">'+S.fmtTime(p.t)+'</div></div><div class="spacer"></div></div>';
      h+='<p style="margin:12px 0;font-size:15px;line-height:1.6">'+UI.escapeHTML(p.text)+'</p>';
      h+='<div class="row-flex" style="gap:18px;color:var(--muted);font-size:13px"><button class="icon-btn" onclick="LOYEDUI.likePost(\''+p.id+'\')">❤️ '+p.likes+'</button><button class="icon-btn">💬 '+p.comments+'</button><button class="icon-btn">🔁 '+p.reposts+'</button></div></div>';
    });
    h+='</div>';
    root.innerHTML=h;
  });
  UI.newPost = function(){
    var body='<label class="reg-label">منشور جديد</label><textarea class="reg-input" id="postTxt" rows="4" placeholder="ماذا تفكّر؟"></textarea>';
    body+='<div class="seg"><button class="active">للجميع</button><button>المتابعون</button></div>';
    UI.modal({title:"منشور جديد",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إلغاء</button><button class="btn-primary neon" onclick="LOYEDUI.doPost()">نشر</button>'});
  };
  UI.doPost = function(){
    var v=document.getElementById("postTxt").value.trim(); if(!v){UI.toast("اكتب شيئاً");return;}
    var st=S.get();
    st.social.unshift({id:"p"+Date.now(),userId:"me",text:v,likes:0,comments:0,reposts:0,t:Date.now()});
    S.save(); UI.closeModal(); UI.navTo("social"); UI.toast("تم النشر ✨");
  };
  UI.likePost = function(id){
    var p=S.get().social.find(function(x){return x.id===id;});
    if(p){ p.likes++; S.save(); UI.navTo("social"); }
  };

  /* ============================================================
     MORE SCREENS
     ============================================================ */

  // AI Assistant
  MORE_SCREENS.ai = function(){
    var body='<div id="aiChat" style="display:flex;flex-direction:column;gap:8px;max-height:55vh;overflow-y:auto;padding:10px"></div>';
    body+='<div class="cv-composer"><input class="cv-input" id="aiInput" placeholder="اسأل LOYED AI..." onkeydown="if(event.key===\'Enter\')LOYEDUI.aiSend()"/><button class="cv-ico cv-send" onclick="LOYEDUI.aiSend()">➤</button></div>';
    UI.modal({title:"LOYED AI ✨",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إغلاق</button>'});
    var c=document.getElementById("aiChat");
    c.innerHTML='<div class="ai-bubble ai"><strong>LOYED AI</strong><br>أهلاً! أنا مساعدك الذكي. أقدر أساعدك في الردود، الترجمة، التلخيص، والإجابة على أسئلتك. اسألني أي حاجة 👇</div>';
  };
  UI.aiSend = function(){
    var inp=document.getElementById("aiInput"); var q=inp.value.trim(); if(!q)return;
    var c=document.getElementById("aiChat");
    c.innerHTML+='<div class="ai-bubble user">'+UI.escapeHTML(q)+'</div>';
    inp.value=""; c.scrollTop=c.scrollHeight;
    setTimeout(function(){
      c.innerHTML+='<div class="ai-bubble ai">'+aiReply(q)+'</div>';
      c.scrollTop=c.scrollHeight;
    }, 700);
  };
  function aiReply(q){
    var l=q.toLowerCase();
    if(l.indexOf("مرحبا")>=0||l.indexOf("hello")>=0||l.indexOf("هاي")>=0) return "أهلاً وسهلاً بيك في LOYED 💜 — محتاج مساعدة في إيه؟";
    if(l.indexOf("ترجم")>=0||l.indexOf("translate")>=0) return "ممكن أترجم أي نص. ابعت النص واللغة المستهدفة، وأنا هترجمه لك. مثال: «ترجم: how are you»";
    if(l.indexOf("لخص")>=0||l.indexOf("summary")>=0) return "ابعت المحادثة أو النص وأنا هلخّصلك أهم النقاط.";
    if(l.indexOf("رد")>=0||l.indexOf("reply")>=0) return "اقتراح رد: «تمام، شكراً ليك! هرد عليك قريب.»";
    return "سؤال حلو! أنا مساعد LOYED AI التجريبي. في النسخة الكاملة هتقدر تاخد ردود ذكية، ترجمة، تلخيص محادثات، وكتيير. جرّب تسألني عن «ترجمة» أو «تلخيص».";
  }

  // Bots
  MORE_SCREENS.bots = function(){
    var st=S.get();
    var body='<div class="grid grid-2">';
    st.bots.forEach(function(b){
      body+='<div class="card"><div class="row-flex"><div class="avatar bot sm">🤖</div><div><div style="font-weight:700">'+b.name+'</div><div style="font-size:11px;color:var(--muted)">'+b.loyedId+'</div></div><div class="spacer"></div><span class="pill '+(b.active?'active':'off')+'">'+(b.active?"يعمل":"متوقف")+'</span></div><p style="margin:10px 0;font-size:13px">'+b.desc+'</p><p style="font-size:11px;color:var(--muted)">'+b.users+' مستخدم · '+b.lang+'</p></div>';
    });
    body+='</div>';
    body+='<button class="btn-primary neon" style="width:100%;margin-top:14px" onclick="LOYEDUI.toast(\'منشئ البوتات — تجريبي\')">＋ إنشاء بوت جديد</button>';
    UI.modal({title:"LOYED Bot Studio 🤖",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إغلاق</button>'});
  };

  // Store
  MORE_SCREENS.store = function(){
    var st=S.get();
    var body='<div class="set-section"><h2>الثيمات</h2><div class="grid grid-3">';
    st.store.filter(function(s){return s.cat==="theme";}).forEach(function(s){
      body+='<div class="tile" onclick="LOYEDUI.buyStore(\''+s.id+'\')"><div class="t-ico">'+s.icon+'</div><div class="t-name">'+s.name+'</div><div class="t-sub">'+(s.price===0?"مجاني":"$"+s.price)+'</div></div>';
    });
    body+='</div></div><div class="set-section"><h2>الملصقات والإيموجي</h2><div class="grid grid-3">';
    st.store.filter(function(s){return s.cat==="sticker"||s.cat==="emoji";}).forEach(function(s){
      body+='<div class="tile" onclick="LOYEDUI.buyStore(\''+s.id+'\')"><div class="t-ico">'+s.icon+'</div><div class="t-name">'+s.name+'</div><div class="t-sub">'+(s.price===0?"مجاني":"$"+s.price)+'</div></div>';
    });
    body+='</div></div><div class="set-section"><h2>الخطوط والأيقونات</h2><div class="grid grid-3">';
    st.store.filter(function(s){return s.cat==="font"||s.cat==="icon";}).forEach(function(s){
      body+='<div class="tile" onclick="LOYEDUI.buyStore(\''+s.id+'\')"><div class="t-ico">'+s.icon+'</div><div class="t-name">'+s.name+'</div><div class="t-sub">'+(s.price===0?"مجاني":"$"+s.price)+'</div></div>';
    });
    body+='</div></div>';
    UI.modal({title:"LOYED Store 🛍️",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إغلاق</button>'});
  };
  UI.buyStore = function(id){
    var s=S.get().store.find(function(x){return x.id===id;});
    if(s.price===0){ UI.toast("تم التثبيت مجاناً ✓"); }
    else { UI.toast("هذا العنصر مدفوع ($"+s.price+") — يلزم اشتراك"); }
  };

  // Cloud
  MORE_SCREENS.cloud = function(){
    var st=S.get();
    var used=8.4; var total = st.me.plan==="pro"?100:5;
    var body='<div class="card" style="margin-bottom:14px"><div class="sc-label">المساحة المستخدمة</div><div class="sc-val">'+used+' GB / '+total+' GB</div><div style="background:var(--border);height:8px;border-radius:4px;margin-top:8px"><div style="background:linear-gradient(90deg,var(--accent),var(--neon));height:100%;width:'+(used/total*100)+'%;border-radius:4px"></div></div></div>';
    body+='<div class="section-title">📁 ملفاتي</div><div class="list">';
    st.cloud.forEach(function(f){
      var ico={pdf:"📄",image:"🖼️",audio:"🎵",data:"💾"}[f.type]||"📄";
      body+='<div class="list-item"><div class="avatar sm" style="background:var(--elev)">'+ico+'</div><div class="li-body"><div class="li-name">'+f.name+'</div><div class="li-msg">'+f.size+' · '+S.fmtTime(f.t)+'</div></div><button class="icon-btn">⬇️</button></div>';
    });
    body+='</div><button class="btn-primary neon" style="width:100%;margin-top:14px" onclick="LOYEDUI.toast(\'رفع ملف — تجريبي\')">＋ رفع ملف</button>';
    UI.modal({title:"LOYED Cloud ☁️",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إغلاق</button>'});
  };

  // Academy
  MORE_SCREENS.academy = function(){
    var st=S.get();
    var body='<div class="grid grid-2">';
    st.academy.forEach(function(a){
      var u=S.findContact(a.teacher);
      body+='<div class="card"><div style="font-size:13px;color:var(--neon);font-weight:700">'+a.level+'</div><h3 style="margin:6px 0">'+a.title+'</h3><p style="font-size:12px">الأستاذ: '+u.name+'</p><div class="row-flex" style="margin-top:8px;font-size:12px;color:var(--muted)"><span>📚 '+a.lessons+' درس</span><span class="spacer"></span><span>👥 '+a.students+'</span></div></div>';
    });
    body+='</div>';
    body+='<div class="section-title">🏫 غرف مباشرة</div><div class="grid grid-2"><div class="tile" onclick="LOYEDUI.toast(\'غرفة رياضيات — تجريبي\')"><div class="t-ico">📐</div><div class="t-name">غرفة الرياضيات</div><div class="t-sub">12 طالب أونلاين</div></div><div class="tile" onclick="LOYEDUI.toast(\'غرفة برمجة — تجريبي\')"><div class="t-ico">💻</div><div class="t-name">غرفة البرمجة</div><div class="t-sub">28 طالب أونلاين</div></div></div>';
    UI.modal({title:"LOYED Academy 🎓",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إغلاق</button>'});
  };

  // Live
  MORE_SCREENS.live = function(){
    var body='<div class="grid grid-2"><div class="tile" onclick="LOYEDUI.toast(\'بدء البث — تجريبي\')"><div class="t-ico">📡</div><div class="t-name">ابدأ بثاً مباشراً</div></div><div class="tile" onclick="LOYEDUI.toast(\'غرفة صوتية — تجريبي\')"><div class="t-ico">🎙️</div><div class="t-name">غرفة صوتية</div></div></div>';
    body+='<div class="section-title">🔴 بثوث مباشرة الآن</div><div class="list"><div class="list-item"><div class="avatar group">📡</div><div class="li-body"><div class="li-name">قمة المطورين</div><div class="li-msg">340 مشاهد</div></div></div><div class="list-item"><div class="avatar group">🎤</div><div class="li-body"><div class="li-name">جلسة أسئلة وأجوبة</div><div class="li-msg">128 مشاهد</div></div></div></div>';
    UI.modal({title:"LOYED Live 📡",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إغلاق</button>'});
  };

  // Gaming
  MORE_SCREENS.gaming = function(){
    var st=S.get();
    var body='<div class="grid grid-2">';
    st.games.forEach(function(g){
      body+='<div class="tile" onclick="LOYEDUI.toast(\'بدء '+g.name+' — تجريبي\')"><div class="t-ico">'+g.icon+'</div><div class="t-name">'+g.name+'</div><div class="t-sub">'+g.players+' لاعب · '+g.desc+'</div></div>';
    });
    body+='</div><div class="section-title">🏆 لوحة الصدارة</div><div class="list"><div class="list-item"><div class="avatar sm" style="background:linear-gradient(135deg,#f59e0b,#d97706)">🥇</div><div class="li-body"><div class="li-name">Emily Clark</div><div class="li-msg">12,400 XP</div></div></div><div class="list-item"><div class="avatar sm" style="background:linear-gradient(135deg,#94a3b8,#64748b)">🥈</div><div class="li-body"><div class="li-name">أحمد المصري</div><div class="li-msg">9,820 XP</div></div></div><div class="list-item"><div class="avatar sm" style="background:linear-gradient(135deg,#b45309,#92400e)">🥉</div><div class="li-body"><div class="li-name">خالد الدوسري</div><div class="li-msg">7,540 XP</div></div></div></div>';
    body+='<p style="font-size:11px;color:var(--muted);margin-top:10px">النقاط افتراضية وغير قابلة للسحب النقدي.</p>';
    UI.modal({title:"LOYED Gaming 🎮",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إغلاق</button>'});
  };

  // Translate
  MORE_SCREENS.translate = function(){
    var body='<label class="reg-label">النص</label><textarea class="reg-input" id="trIn" rows="3" placeholder="اكتب نصاً للترجمة"></textarea>';
    body+='<div class="row-flex" style="gap:8px;margin:8px 0"><select class="cc" id="trTo"><option value="ar">→ العربية</option><option value="en">→ English</option><option value="fr">→ Français</option><option value="es">→ Español</option><option value="ja">→ 日本語</option></select></div>';
    body+='<div id="trOut" style="background:var(--bg-2);border-radius:10px;padding:14px;min-height:50px;color:var(--muted);font-size:14px">ستظهر الترجمة هنا</div>';
    body+='<p style="font-size:11px;color:var(--muted);margin-top:8px">⚠️ ترجمة محاكاة — في الإنتاج ترتبط بخدمة ترجمة فعلية.</p>';
    UI.modal({title:"الترجمة الذكية 🌐",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إغلاق</button><button class="btn-primary neon" onclick="LOYEDUI.doTranslate()">ترجم</button>'});
  };
  UI.doTranslate = function(){
    var txt=document.getElementById("trIn").value.trim(); var to=document.getElementById("trTo").value;
    if(!txt){UI.toast("اكتب نصاً");return;}
    var out=document.getElementById("trOut");
    out.style.color="var(--text)";
    // simulated translation
    var dict={ "مرحبا":{en:"Hello",fr:"Bonjour",es:"Hola",ja:"こんにちは",ar:"مرحبا"}, "كيف حالك":{en:"How are you",fr:"Comment ça va",es:"¿Cómo estás",ja:"お元気ですか",ar:"كيف حالك"}, "شكرا":{en:"Thank you",fr:"Merci",es:"Gracias",ja:"ありがとう",ar:"شكرا"} };
    var tr=txt;
    Object.keys(dict).forEach(function(k){ if(txt.indexOf(k)>=0){ tr=dict[k][to]||txt; } });
    out.innerHTML='<div style="font-size:11px;color:var(--muted);margin-bottom:6px">الترجمة ('+to+'):</div>'+UI.escapeHTML(tr)+(tr===txt?'<div style="font-size:11px;color:var(--muted);margin-top:6px">(عرض توضيحي — الترجمة الفعلية تتطلب خدمة خارجية)</div>':'');
  };

  // Stickers
  MORE_SCREENS.stickers = function(){
    var body='<div class="set-section"><h2>😀 الإيموجي</h2><div class="emoji-pal">';
    var emojis=["😀","😂","🥰","😍","😎","🤔","😢","😡","👍","👎","❤️","🔥","✨","🎉","💜","💯","🙏","🚀","🌙","⭐","🥳","😱","🤯","👏","💪","🎯","🌟","⚡","🦄","🌈"];
    emojis.forEach(function(e){ body+='<button onclick="LOYEDUI.toast(\''+e+'\')">'+e+'</button>'; });
    body+='</div></div><div class="set-section"><h2>✨ الملصقات</h2><div class="grid grid-3"><div class="tile" onclick="LOYEDUI.navTo(\'more\');setTimeout(function(){LOYEDUI.openMore(\'store\',false,null)},100);LOYEDUI.closeModal()"><div class="t-ico">🛍️</div><div class="t-name">متجر الملصقات</div></div></div></div>';
    body+='<div class="set-section"><h2>⌨️ كيبورد LOYED</h2><div class="set-row"><span class="sr-ico">⌨️</span><div class="sr-body"><div class="sr-title">تفعيل كيبورد LOYED</div><div class="sr-sub">ثيمات وأصوات ضغطات</div></div><label class="switch"><input type="checkbox" onchange="LOYEDUI.toast(\'يتطلب تفعيل من إعدادات النظام\')"/><span class="slider"></span></label></div></div>';
    UI.modal({title:"الملصقات والإيموجي 😀",body:body,foot:'<button class="btn-ghost" onclick="LOYEDUI.closeModal()">إغلاق</button>'});
  };

})();
